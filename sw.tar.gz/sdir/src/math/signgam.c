#include <math.h>
#include "libm.h"

int __signgam = 0;

weak_alias(__signgam, signgam);
