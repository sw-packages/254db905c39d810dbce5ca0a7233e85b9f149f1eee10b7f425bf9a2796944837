#ifndef INTSCAN_H
#define INTSCAN_H

#include <stdio.h>

hidden unsigned long long __intscan(FILE *, unsigned, int, unsigned long long);

#endif
