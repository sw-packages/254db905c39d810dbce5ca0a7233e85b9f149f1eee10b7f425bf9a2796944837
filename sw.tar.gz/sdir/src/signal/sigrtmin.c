#include <signal.h>

int __libc_current_sigrtmin()
{
	return 35;
}
