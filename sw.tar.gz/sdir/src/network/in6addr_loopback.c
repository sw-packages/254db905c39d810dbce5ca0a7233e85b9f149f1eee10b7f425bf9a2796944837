#include <netinet/in.h>

const struct in6_addr in6addr_loopback = IN6ADDR_LOOPBACK_INIT;
