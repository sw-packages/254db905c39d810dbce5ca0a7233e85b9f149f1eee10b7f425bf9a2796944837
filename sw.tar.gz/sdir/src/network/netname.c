#include <netdb.h>

struct netent *getnetbyaddr(uint32_t net, int type)
{
	return 0;
}

struct netent *getnetbyname(const char *name)
{
	return 0;
}

