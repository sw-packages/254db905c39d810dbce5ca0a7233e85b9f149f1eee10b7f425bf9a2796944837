#include <unistd.h>

long gethostid()
{
	return 0;
}
