#include <stdlib.h>

int abs(int a)
{
	return a>0 ? a : -a;
}
