#include <stdlib.h>

double atof(const char *s)
{
	return strtod(s, 0);
}
