#if __ARMEB__ || __thumb__
#include "../memcpy.c"
#endif
