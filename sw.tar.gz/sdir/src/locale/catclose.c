#include <nl_types.h>

int catclose (nl_catd catd)
{
	return 0;
}
